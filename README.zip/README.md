# SliderPuzzleGame
Slider Puzzle Game adalah sebuah game yang dimainkan dengan cara menyusun angka dari 1-15.
Sistem permainan nya sangat mudah, pemain diberikan waktu sebanyak 2 menit untuk menyusun puzzle tersebut. Maximal langkah yang dilakukan untuk menyusun puzzle sebanyak 150 dan jika pemain tidak dapat menyelesaikan puzzle dalam waktu 2 menit dan melakukan langkah sebanyak 150 kali maka pemain langsung kalah.

# Dibuat Oleh
Mas Rafi Fauzan Ontowiryo (1806200040)
Fadly Ahmad Firdausy (1806200343)
